import React from 'react';
import './lightboxv.css';
import { useHistory } from 'react-router-dom';

const LightboxV = ({ onClose, name, uniqueId }) => {
    const history = useHistory();
  
    const handleCheckStatusClick = () => {
        onClose(); // Close the lightbox
        // Store the unique ID in localStorage (or sessionStorage) for retrieval in Validity.js
        localStorage.setItem('uniqueId', uniqueId);
        history.push('/valid'); // Redirect to the validity check page
    };

    return (
        <>
            <div className="lightbox-overlay" onClick={onClose}></div> {/* Click to close the lightbox */}
            <div className="container">
                <div className="header">
                    <span className="close-icon" onClick={onClose}>X</span>
                    <h2>Verification Request Sent</h2>
                </div>
                <div className="content">
                    <p>Hello, {name}!</p>
                    <p>Your verification request has been successfully submitted.</p>
                    <p>Your unique ID is: {uniqueId}</p>
                    <div className="caution">
                        <span className="caution-icon">⚠️</span>
                        <span className="caution-text">
                            Caution: Do not share this ID with anyone. It's for your personal use only.
                        </span>
                    </div>
                    <p>Please keep this ID for your records. You'll need it to check your verification status.</p>
                </div>
                <div className="footer">
                    <button className="check-status-button" onClick={handleCheckStatusClick}>Check Status</button>
                </div>
            </div>
        </>
    );
};

export default LightboxV;
