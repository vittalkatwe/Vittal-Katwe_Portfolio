import React, { Fragment } from 'react'

import PropTypes from 'prop-types'

import './content.css'

const Content = (props) => {
  return (
    <div className={`content-content ${props.rootClassName} `}>
      <h1 className="content-title">
        {props.title ?? (
          <Fragment>
            <h1 className="content-text2">
              Your local social network. Find people like you. Meet up for fun.
            </h1>
          </Fragment>
        )}
      </h1>
      <div className="content-hero-buttons">
        <div className="content-ios-btn">
          <span>
            {props.caption ?? (
              <Fragment>
                <span className="content-text1">Get Started</span>
              </Fragment>
            )}
          </span>
        </div>
      </div>
    </div>
  )
}

Content.defaultProps = {
  caption: undefined,
  title: undefined,
  rootClassName: '',
}

Content.propTypes = {
  caption: PropTypes.element,
  title: PropTypes.element,
  rootClassName: PropTypes.string,
}

export default Content
