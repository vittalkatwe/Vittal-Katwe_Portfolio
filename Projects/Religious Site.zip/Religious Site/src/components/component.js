import React from 'react'

import PropTypes from 'prop-types'

import './component.css'

const AppComponent = (props) => {
  return (
    <div className={`component-container ${props.rootClassName} `}>
      <img
        alt={props.imageAlt}
        src={props.imageSrc}
        className="component-image1"
      />
      <img
        alt={props.imageAlt1}
        src={props.imageSrc1}
        className="component-image2"
      />
      <img
        alt={props.imageAlt2}
        src={props.imageSrc2}
        className="component-image3"
      />
    </div>
  )
}

AppComponent.defaultProps = {
  imageAlt: 'image',
  imageAlt2: 'image',
  imageAlt1: 'image',
  imageSrc2: '/character-1.svg',
  imageSrc1: '/character-3.svg',
  rootClassName: '',
  imageSrc: '/character-10.svg',
}

AppComponent.propTypes = {
  imageAlt: PropTypes.string,
  imageAlt2: PropTypes.string,
  imageAlt1: PropTypes.string,
  imageSrc2: PropTypes.string,
  imageSrc1: PropTypes.string,
  rootClassName: PropTypes.string,
  imageSrc: PropTypes.string,
}

export default AppComponent
