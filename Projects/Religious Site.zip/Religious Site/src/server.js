const express = require('express');
const cors = require('cors');
const { MongoClient } = require('mongodb');
const multer = require('multer');
const path = require('path');
const fs = require('fs'); // Added to ensure uploads directory exists

const app = express();
const port = 5000;

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB connection
const uri = 'mongodb+srv://vittalskatwe:vittalskatwe@cluster0.9pbgcva.mongodb.net/ssksite?retryWrites=true&w=majority';
const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });

let db;

client.connect()
  .then(() => {
    db = client.db('ssksite'); // Replace 'ssksite' with your actual database name
    console.log('Connected to MongoDB');
  })
  .catch((err) => console.error('Failed to connect to MongoDB', err));

// Create uploads directory if it doesn't exist
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Multer configuration for file upload
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname)); // Append the file extension
  },
});

const upload = multer({ storage });

// Handle form submission
app.post('/submit-form', upload.single('uploadedFile'), async (req, res) => {
  const formData = {
    name: req.body.name,
    age: req.body.age,
    phoneNumber: req.body.phoneNumber,
    idType: req.body.idType,
    uploadedFile: req.file ? `/uploads/${req.file.filename}` : '', // Save the path to the file in the DB
    uniqueId: req.body.uniqueId,  // Capture the unique ID from the request
    status: req.body.status,
  };

  try {
    const collection = db.collection('ssk-form');

    // Check if the unique ID already exists
    const existingEntry = await collection.findOne({ uniqueId: formData.uniqueId });

    if (existingEntry) {
      return res.status(400).json({ message: 'Unique ID already exists. Please try again.' });
    }

    await collection.insertOne(formData);
    res.status(200).json({ message: 'Form submitted successfully!', uniqueId: formData.uniqueId });
  } catch (err) {
    console.error('Error submitting form:', err);
    res.status(500).json({ message: 'Error submitting form', err });
  }
});

// Verify ID endpoint
app.get('/verify/:id', async (req, res) => {
  const uniqueId = req.params.id; // Get the ID from the request parameters

  try {
    // Find the record in the database by unique ID in the 'ssk-form' collection
    const userRecord = await db.collection('ssk-form').findOne({ uniqueId });

    if (userRecord) {
      console.log('Status found:', userRecord.status); // Log the status
      res.status(200).json({ status: userRecord.status }); // Send the status back
    } else {
      res.status(404).json({ message: 'ID not found' });
    }
  } catch (error) {
    console.error('Error fetching ID status:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Serve uploads folder for accessing uploaded files
app.use('/uploads', express.static(uploadDir));

// Endpoint to get all form data
app.get('/form-data', (req, res) => {
  const collection = db.collection('ssk-form');
  collection.find().toArray()
    .then(data => res.status(200).json(data))
    .catch(err => res.status(500).json({ message: 'Error retrieving form data', err }));
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
