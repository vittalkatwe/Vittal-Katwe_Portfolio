import React, { useEffect, useState } from 'react';
import { Link, useHistory } from 'react-router-dom'; // Import useHistory
import './validity.css';
import Announcement from '../components/announcement';

const Validity = () => {
    const [idNumber, setIdNumber] = useState(''); // Store the ID part
    const [status, setStatus] = useState(null);
    const [recentLookups, setRecentLookups] = useState([]);
    const [buttonText, setButtonText] = useState('Order ID'); // Initial button text
    const [isBooking, setIsBooking] = useState(false); // Handle loading state for button
    const [isConfirmed, setIsConfirmed] = useState(false); // Handle confirmation state for button

    const history = useHistory(); // Initialize useHistory

    useEffect(() => {
        // Check localStorage for the unique ID and set it
        const storedUniqueId = localStorage.getItem('uniqueId');
        if (storedUniqueId) {
            setIdNumber(storedUniqueId.replace(/^SSK-/, '')); // Remove the prefix
            localStorage.removeItem('uniqueId'); // Clear the stored ID after retrieving it
        }
    }, []);

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch(`http://localhost:5000/verify/SSK-${idNumber}`);
            const data = await response.json();

            if (response.ok) {
                setStatus(data.status); // Set the status received from the server
            } else {
                setStatus('ID not found'); // Handle case when ID is not found
            }
        } catch (error) {
            console.error('Error verifying ID:', error);
            setStatus('Server error');
        }

        setRecentLookups(prev => [`SSK-${idNumber}`, ...prev.slice(0, 2)]);
    };

    const handleChange = (e) => {
        const value = e.target.value.replace(/^SSK-/, ''); // Allow setting only the ID part
        setIdNumber(value);
    };

    const handleKeyDown = (e) => {
        // Prevent backspacing the prefix
        if (e.key === 'Backspace' && idNumber.length === 0) {
            e.preventDefault();
        }
    };

    const handleButtonClick = () => {
        setIsBooking(true);
        setButtonText('Working on it!');

        // Simulate the booking process
        setTimeout(() => {
            setButtonText('You are being redirected!');
        }, 1000);

        // Redirect to /buycard after 3 seconds
        setTimeout(() => {
            setIsBooking(false);
            setIsConfirmed(true);
            history.push('/buycard'); // Redirect to /buycard
        }, 3000);
    };

    return (
        <div>
            <Link to="/">
                <Announcement
                    rootClassName="announcementroot-class-name"
                    className="home-component"
                ></Announcement>
            </Link>
            <div className="verification-container">
                <div className="verification-card">
                    <div className="card-header">
                        <h2 className="card-title">Verification Status</h2>
                        <p className="card-subtitle">
                            Enter a unique identification number to check the verification status.
                        </p>
                    </div>
                    <div className="card-content">
                        <form onSubmit={handleSubmit} className="verification-form">
                            <div className="form-group">
                                <label htmlFor="idNumber">Identification Number</label>
                                <div className="input-wrapper">
                                    <input
                                        id="idNumber"
                                        type="text"
                                        className='idinput-15'
                                        value={`SSK-${idNumber}`} // Display the full value
                                        onChange={handleChange}
                                        onKeyDown={handleKeyDown}
                                        maxLength={12} // Allow 8 digits + 4 for "SSK-"
                                        required
                                    />
                                </div>
                            </div>
                            <button type="submit" className="submit-button">
                                Check Status
                            </button>
                        </form>

                        {status && (
                            <div className={`status-alert ${status.toLowerCase()}`}>
                                {status === 'Verified' ? '✓' : status === 'Rejected' ? '✗' : ''}
                                <span>
                                    {status === 'Verified' ? 'Verification successful! :)' : 
                                    status === 'Rejected' ? 'Verification failed. Please try again with right details :(' : 
                                    status === 'ID not found' ? '! ID not found :(' : 
                                    'Status is under review.'}
                                </span>
                            </div>
                        )}

                        {/* Show "Order ID" button only if status is Verified */}
                        {status === 'Verified' && (
                            <div className="order-id-container">
                                <button 
                                    onClick={handleButtonClick}
                                    disabled={isBooking || isConfirmed}
                                    className="order-id-button"
                                >
                                    {buttonText}
                                </button>
                            </div>
                        )}

                        <div className="recent-lookups">
                            <h3>Recent Lookups</h3>
                            {recentLookups.length > 0 ? (
                                <ul>
                                    {recentLookups.map((lookup, index) => (
                                        <li key={index}>{lookup}</li>
                                    ))}
                                </ul>
                            ) : (
                                <p>No recent lookups</p>
                            )}
                        </div>

                        <div className="help-link">
                            <Link to='/verify'>
                            <a className='registertxt'>Register</a></Link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Validity;
