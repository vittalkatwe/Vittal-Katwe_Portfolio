import React, { Suspense } from 'react';
import { Helmet } from 'react-helmet';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Text, ContactShadows, Environment } from '@react-three/drei';
import * as THREE from 'three';
import { Link } from 'react-router-dom/cjs/react-router-dom';
import Announcement from '../components/announcement';
import './buycard.css';

const MetallicCardContent = () => {
  const createRoundedRectShape = (width, height, radius) => {
    const shape = new THREE.Shape();
    shape.moveTo(-width / 2 + radius, -height / 2);
    shape.lineTo(width / 2 - radius, -height / 2);
    shape.quadraticCurveTo(width / 2, -height / 2, width / 2, -height / 2 + radius);
    shape.lineTo(width / 2, height / 2 - radius);
    shape.quadraticCurveTo(width / 2, height / 2, width / 2 - radius, height / 2);
    shape.lineTo(-width / 2 + radius, height / 2);
    shape.quadraticCurveTo(-width / 2, height / 2, -width / 2, height / 2 - radius);
    shape.lineTo(-width / 2, -height / 2 + radius);
    shape.quadraticCurveTo(-width / 2, -height / 2, -width / 2 + radius, -height / 2);
    return shape;
  };

  return (
    <>
      <ambientLight intensity={0.5} />
      <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} intensity={1} />
      <pointLight position={[-10, -10, -10]} intensity={0.5} />


      {/* Grouping the card mesh and content */}
      <group rotation={[0, Math.PI, 0]} /* Applying a 180-degree rotation on Y-axis */>
        
        
        <mesh>
          
          <extrudeGeometry
            args={[createRoundedRectShape(3.4, 2.1, 0.1), { depth: 0.05, bevelEnabled: true, bevelThickness: 0.01, bevelSize: 0.01, bevelSegments: 16 }]}
          />

          
          <meshPhysicalMaterial
            color="#8a8a8a"
            metalness={0.9}
            roughness={0.4}
            envMapIntensity={1}
            clearcoat={0.5}
            clearcoatRoughness={0.3}
          />
        </mesh>

        {/* Adding text on the reversed side */}
        <group position={[0, 0, 0.03]}>
          <Text position={[-1.2, 0.7, 0]} fontSize={0.25} color="white" anchorX="left" anchorY="middle">
            John Doe
          </Text>
          <Text position={[-1.2, 0.3, 0]} fontSize={0.18} color="white" anchorX="left" anchorY="middle">
            SSK-12345678
          </Text>
          
        </group>

        {/* Adding content to the flipped side */}
        <group position={[0, 0, -0.03]} rotation={[0, Math.PI, 0]}>
          
        <Text position={[0, 0.87, 0]} fontSize={0.3} fontWeight={800} color="white" anchorX="center" anchorY="middle">
          SSKSamaj
        </Text>
        <Text position={[0.75, 0.81, 0]} fontSize={0.11} fontWeight={800} color="white" anchorX="left" anchorY="middle">
          .in
        </Text>
          <Text className='johntext' position={[-1.48, -0.5, 0]} fontSize={0.28} fontWeight={800} color="white" anchorX="left" anchorY="middle">
            John Doe
          </Text>
          <Text position={[-1.5, -0.9, 0]} fontSize={0.15} color="white" anchorX="left" anchorY="bottom">
            SSK-00000000
          </Text>
        </group>

        {/* Side strip of the card */}
        <mesh position={[0, -0.8, -0.025]} rotation={[0, 0, Math.PI / 2]}>
          <planeGeometry args={[0.5, 3.2]} />
          <meshStandardMaterial color="#1a1a1a" roughness={0.8} />
        </mesh>
      </group>
    </>
  );
};

class MetallicCard extends React.Component {
  render() {
    return (

      <div>
        
        <Announcement
                rootClassName="announcementroot-class-name"
                className="home-component"
              ></Announcement>
      <div className="metallic-card-container">
        
        <Helmet>
          <title>3D Metallic ID Card</title>
        </Helmet>
        <h3>Get Metallic Identity Card Now</h3>
        <div className="metallic-card-canvas-container">
          <Canvas camera={{ position: [0, 0, 6.5], fov: 50 }}>
            <Suspense fallback={null}>
              <MetallicCardContent />
              <OrbitControls enableZoom={false} enablePan={false} />
              <Environment preset="park" />
              <ContactShadows position={[0, -1.5, 0]} opacity={0.4} scale={5} blur={2.5} far={4} />
            </Suspense>
          </Canvas>
        </div>

        {/* Adding Limited Time Offer Section */}
        <div className="limited-time-offer-container">
          <div className='diffback'>
          <p>Order now and get a 20% discount on your Metallic ID Card.</p>
          </div>
        </div>

        <div className="mettalic-button-buy">
          
          <button className="metallic-card-button2">
            <img src="/New Folder/share.png" alt="Share Icon" className="share-image" />
            Share
          </button>
          
        </div>
        <div className="metallic-card-button-container">
          <Link to="/checkout">
          <button className="metallic-card-button">Buy Now</button></Link>
        </div>
      </div>
      
      </div>
    );
  }
}

export default MetallicCard;
