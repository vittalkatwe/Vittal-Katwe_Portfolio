import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Announcement from '../components/announcement';
import LightboxV from '../components/lightboxv'; // Import your Lightbox component

const styles = {
  container: {
    maxWidth: '400px',
    margin: '0 auto',
    padding: '20px',
    marginTop: '55px',
    fontFamily: 'Arial, sans-serif',
    backgroundColor: '#fff',
    borderRadius: '8px',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
  },
  title: {
    fontSize: '24px',
    fontWeight: 'bold',
    marginBottom: '5px',
  },
  subtitle: {
    fontSize: '14px',
    color: '#666',
    marginBottom: '20px',
  },
  formGroup: {
    marginBottom: '15px',
  },
  label: {
    display: 'block',
    fontSize: '14px',
    fontWeight: 'bold',
    marginBottom: '5px',
    color: '#333',
  },
  input: {
    width: '100%',
    padding: '8px',
    fontSize: '14px',
    border: '1px solid #ccc',
    borderRadius: '4px',
    boxSizing: 'border-box',
  },
  select: {
    width: '100%',
    padding: '8px',
    fontSize: '14px',
    border: '1px solid #ccc',
    borderRadius: '4px',
    backgroundColor: '#fff',
    boxSizing: 'border-box',
  },
  fileInput: {
    display: 'none',
  },
  fileInputLabel: {
    display: 'inline-block',
    padding: '8px 12px',
    fontSize: '14px',
    fontWeight: 'normal',
    color: '#333',
    backgroundColor: '#fff',
    border: '1px solid #ccc',
    borderRadius: '4px',
    cursor: 'pointer',
  },
  fileInputText: {
    marginLeft: '10px',
    fontSize: '14px',
    color: '#666',
  },
  submitButton: {
    width: '100%',
    padding: '10px',
    fontSize: '16px',
    color: '#fff',
    backgroundColor: '#000',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
  },
  error: {
    color: 'red',
    fontSize: '12px',
    marginTop: '5px',
  },
};

const VerifyIdentity = () => {
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    phoneNumber: '',
    idType: 'aadhar',
    uploadedFile: null,
    status: 'Under Review', // New status variable
  });

  const [errors, setErrors] = useState({});
  const [isLightboxOpen, setLightboxOpen] = useState(false);
  const [uniqueId, setUniqueId] = useState(''); // State for the unique ID
  const [userName, setUserName] = useState(''); // State for the user's name

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleFileChange = (e) => {
    setFormData({ ...formData, uploadedFile: e.target.files[0] });
  };

  // Validation function
  const validateForm = () => {
    const newErrors = {};

    // Full name should be at least two words with each word having at least two characters
    const fullNameRegex = /^[a-zA-Z]{2,}\s[a-zA-Z]{2,}$/;
    if (!fullNameRegex.test(formData.name)) {
      newErrors.name = 'Please enter your full name (first and last name).';
    }

    // Age should be greater than 14
    if (formData.age <= 14) {
      newErrors.age = 'Age must be above 14.';
    }

    // Phone number should be exactly 10 digits
    const phoneNumberRegex = /^\d{10}$/;
    if (!phoneNumberRegex.test(formData.phoneNumber)) {
      newErrors.phoneNumber = 'Phone number must be exactly 10 digits.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Check if form is valid
    if (!validateForm()) {
      return;
    }

    // Generate a unique ID with the format SSK- followed by an 8-digit number
    const generatedUniqueId = `SSK-${Math.floor(10000000 + Math.random() * 90000000)}`;
    setUniqueId(generatedUniqueId); // Store the generated ID in state
    setUserName(formData.name); // Store the user's name in state

    const formDataToSend = new FormData();
    formDataToSend.append('name', formData.name);
    formDataToSend.append('age', formData.age);
    formDataToSend.append('phoneNumber', formData.phoneNumber);
    formDataToSend.append('idType', formData.idType);
    formDataToSend.append('uploadedFile', formData.uploadedFile);
    formDataToSend.append('uniqueId', generatedUniqueId); // Append the unique ID
    formDataToSend.append('status', formData.status); // Append the status

    fetch('http://localhost:5000/submit-form', {
      method: 'POST',
      body: formDataToSend,
    })
      .then(response => response.json())
      .then(data => {
        console.log('Success:', data);
        setLightboxOpen(true); // Open lightbox on successful submission
      })
      .catch(error => {
        console.error('Error:', error);
      });
  };

  const handleCloseLightbox = () => {
    setLightboxOpen(false); // Function to close the lightbox
  };

  return (
    <div>
      <Link to="/">
        <Announcement
          rootClassName="announcementroot-class-name"
          className="home-component"
        />
      </Link>
      <div style={styles.container}>
        <h1 style={styles.title}>Verify your identity</h1>
        <p style={styles.subtitle}>Please fill in your details</p>
        <form onSubmit={handleSubmit}>
          <div style={styles.formGroup}>
            <label htmlFor="name" style={styles.label}>Name</label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleInputChange}
              style={styles.input}
              required
            />
            {errors.name && <div style={styles.error}>{errors.name}</div>}
          </div>
          <div style={styles.formGroup}>
            <label htmlFor="age" style={styles.label}>Age</label>
            <input
              type="number"
              id="age"
              name="age"
              value={formData.age}
              onChange={handleInputChange}
              style={styles.input}
              required
            />
            {errors.age && <div style={styles.error}>{errors.age}</div>}
          </div>
          <div style={styles.formGroup}>
            <label htmlFor="phoneNumber" style={styles.label}>Phone Number</label>
            <input
              type="tel"
              id="phoneNumber"
              name="phoneNumber"
              value={formData.phoneNumber}
              onChange={handleInputChange}
              style={styles.input}
              required
            />
            {errors.phoneNumber && <div style={styles.error}>{errors.phoneNumber}</div>}
          </div>
          <div style={styles.formGroup}>
            <label htmlFor="idType" style={styles.label}>ID Type</label>
            <select
              id="idType"
              name="idType"
              value={formData.idType}
              onChange={handleInputChange}
              style={styles.select}
            >
              <option value="aadhar">Aadhar Card</option>
              <option value="pan">PAN Card</option>
            </select>
          </div>
          <div style={styles.formGroup}>
            <label htmlFor="uploadId" style={styles.label}>Upload ID</label>
            <div>
              <label htmlFor="uploadId" style={styles.fileInputLabel}>
                Choose File
                <input
                  type="file"
                  id="uploadId"
                  name="uploadedFile" 
                  style={styles.fileInput}
                  onChange={handleFileChange}
                  accept="/*" // Accept only image files
                  required
                />
              </label>
              {formData.uploadedFile && (
                <span style={styles.fileInputText}>
                  {formData.uploadedFile.name}
                </span>
              )}
            </div>
          </div>
          <button type="submit" style={styles.submitButton}>
            Submit
          </button>
        </form>
        {isLightboxOpen && (
          <LightboxV
            uniqueId={uniqueId}
            userName={userName}
            onClose={handleCloseLightbox}
          />
        )}
      </div>
    </div>
  );
};

export default VerifyIdentity;
