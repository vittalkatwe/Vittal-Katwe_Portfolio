import React from 'react'
import { Link } from 'react-router-dom'

import { Helmet } from 'react-helmet'

import Announcement from '../components/announcement'
import './home.css'

const Home = (props) => {
  return (
    <div className="home-container1">
      <Helmet>
        <title>Finbest</title>
        <meta name="description" content="Description of the website" />
        <meta property="og:title" content="Finbest" />
        <meta property="og:description" content="Description of the website" />
      </Helmet>
      <div className="home-hero">
        <header className="home-heading">
          <div id="notifcation" className="home-notification">
            <Link to="/">
              <Announcement
                rootClassName="announcementroot-class-name"
                className="home-component"
              ></Announcement>
            </Link>
          </div>
        </header>
        <div className="home-content1">
          <div className="home-content2">
            <h1 className="home-title">
              <span>
                Get Verified by SSK
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
              <br></br>
              <span>Samaj</span>
              <span className="home-text4">.in</span>
            </h1>
            <div className="home-hero-buttons">
              <div className="home-ios-btn1"><Link to='/verify'>
                <span className="home-caption1">Apply for Verification</span></Link>
              </div>
              <div className="home-ios-btn2"><Link to='/valid'>
                <span className="home-caption2">Apply for ID</span></Link>
              </div>
            </div>
          </div>
          <div className="home-container2">
            <div className="home-container3">
              <img
                src="/New Folder/screenshot.png"
                alt="image"
                className="home-image"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Home
