import { useState } from "react";
import { CreditCard } from "lucide-react";
import './checkout.css';

export default function CheckoutCard() {
  const [selectedCards, setSelectedCards] = useState({
    metallic: true,
    regular: false,
  });

  const [uniqueId, setUniqueId] = useState("");

  const metalCardPrice = 349.99;
  const regularCardPrice = 169.99;
  const shippingPrice = 64.99;

  const totalPrice =
    (selectedCards.metallic ? metalCardPrice : 0) +
    (selectedCards.regular ? regularCardPrice : 0) +
    shippingPrice;

  const handleCardSelection = (cardType: "metallic" | "regular") => {
    setSelectedCards((prev) => {
      const newSelection = { ...prev, [cardType]: !prev[cardType] };
      if (!newSelection.metallic && !newSelection.regular) {
        newSelection[cardType] = true;
      }
      return newSelection;
    });
  };

  const handleUniqueIdChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputVal = e.target.value.replace(/\D/g, ''); // Remove all non-numeric characters
    if (inputVal.length <= 8) { // Limit to 8 digits
      setUniqueId(inputVal);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-100 to-indigo-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md overflow-hidden">
        <div className="bg-gradient-to-r from-blue-500 to-indigo-600 p-6 text-white">
          <h2 className="text-2xl font-bold">Checkout</h2>
          <p className="text-blue-100">Complete your order</p>
        </div>
        <div className="p-6 space-y-6">
          {/* Order Summary */}
          <div className="space-y-3">
            <h3 className="font-semibold text-lg text-gray-700">Order Summary</h3>
            <div className="space-y-2">
              <label className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg transition duration-150 ease-in-out hover:bg-gray-100">
                <input
                  type="checkbox"
                  checked={selectedCards.metallic}
                  onChange={() => handleCardSelection("metallic")}
                  className="form-checkbox h-5 w-5 text-blue-600 rounded border-gray-300 focus:ring-blue-500"
                />
                <span className="flex-grow">
                  <span className="text-sm font-medium text-gray-900">Metallic Identity Card</span>
                  <span className="block text-sm text-gray-500">Premium metal finish</span>
                </span>
                <span className="text-sm font-semibold text-gray-900">₹ {metalCardPrice.toFixed(2)}</span>
              </label>
              <label className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg transition duration-150 ease-in-out hover:bg-gray-100">
                <input
                  type="checkbox"
                  checked={selectedCards.regular}
                  onChange={() => handleCardSelection("regular")}
                  className="form-checkbox h-5 w-5 text-blue-600 rounded border-gray-300 focus:ring-blue-500"
                />
                <span className="flex-grow">
                  <span className="text-sm font-medium text-gray-900">Regular Identity Card</span>
                  <span className="block text-sm text-gray-500">Standard plastic card</span>
                </span>
                <span className="text-sm font-semibold text-gray-900">₹ {regularCardPrice.toFixed(2)}</span>
              </label>
            </div>
            <div className="flex justify-between items-center text-sm text-gray-600 pt-3 border-t">
              <span>Shipping</span>
              <span>₹ {shippingPrice.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center text-lg font-semibold text-gray-900 pt-3 border-t">
              <span>Total</span>
              <span>₹ {totalPrice.toFixed(2)}</span>
            </div>
          </div>

          {/* Unique ID Input */}
          <div className="space-y-2">
            <label htmlFor="uniqueId" className="block text-sm font-medium text-gray-700">Unique ID</label>
            <div className="mt-1 relative rounded-md shadow-sm">
              <CreditCard className="cardicon" />
              <input
                id="uniqueId"
                type="text"
                value={`SSK-${uniqueId}`}
                onChange={handleUniqueIdChange}
                placeholder="Enter your Unique ID"
                className="block w-full pl-16 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                required
              />
            </div>
          </div>

          {/* Shipping Information */}
          <div className="space-y-3">
            <h3 className="font-semibold text-lg text-gray-700">Shipping Information</h3>
            <div className="grid grid-cols-2 gap-3">
              <input
                placeholder="First Name"
                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                required
              />
              <input
                placeholder="Last Name"
                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                required
              />
            </div>
            <input
              placeholder="Address"
              className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              required
            />
            <div className="grid grid-cols-2 gap-3">
              <input
                placeholder="City"
                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                required
              />
              <input
                placeholder="Postal Code"
                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                required
              />
            </div>
          </div>
        </div>
        <div className="px-6 py-4 bg-gray-50 border-t border-gray-200">
          <button
            className="w-full px-4 py-3 bg-gradient-to-r from-blue-500 to-indigo-600 text-white font-semibold rounded-md shadow-sm hover:from-blue-600 hover:to-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-150 ease-in-out"
          >
            Place Order
          </button>
        </div>
      </div>
    </div>
  );
}
