package com.database.doctorsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoctorsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
